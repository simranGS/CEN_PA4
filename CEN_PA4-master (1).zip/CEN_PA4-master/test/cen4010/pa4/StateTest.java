package cen4010.pa4;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Component;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import javax.swing.JButton;

import org.junit.jupiter.api.Test;

import cen4010.pa4.core.State;
import cen4010.pa4.core.Window;

public class StateTest {
	GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
	GraphicsDevice graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();
	GraphicsConfiguration graphicsConfiguration = graphicsDevice.getDefaultConfiguration();
	
	@Test
	void windowTest() {
		Window w1 = new Window(500, 500, graphicsConfiguration);
		
		State test1 = new State("Test1", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		
		test1.setWindow(w1);
		
		w1.addState(test1);
		w1.pushState("Test1");
		
		JButton testButton = new JButton("Test Button");
		test1.addComponent(testButton);
		test1.addComponent(testButton, null);
		
		Window wt = test1.getWindow();
		assertEquals(wt, w1);
	}
}
