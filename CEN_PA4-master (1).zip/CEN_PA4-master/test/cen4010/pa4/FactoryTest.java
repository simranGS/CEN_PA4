package cen4010.pa4;

import static org.junit.Assert.assertTrue;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import org.junit.jupiter.api.*;

import cen4010.pa4.factory.AbstractFactory;
import cen4010.pa4.factory.Factory;
import cen4010.pa4.factory.Theme;
import cen4010.pa4.factory.darkTheme.DarkButton;
import cen4010.pa4.factory.darkTheme.DarkFactory;
import cen4010.pa4.factory.darkTheme.DarkLabel;
import cen4010.pa4.factory.darkTheme.DarkPanel;
import cen4010.pa4.factory.darkTheme.DarkRadioButton;
import cen4010.pa4.factory.defaultTheme.DefaultButton;
import cen4010.pa4.factory.defaultTheme.DefaultFactory;
import cen4010.pa4.factory.defaultTheme.DefaultLabel;
import cen4010.pa4.factory.defaultTheme.DefaultPanel;
import cen4010.pa4.factory.defaultTheme.DefaultRadioButton;

public class FactoryTest {
	@Test
	void factoryTest() {
		AbstractFactory factory = Factory.getFactory(Theme.Default);
		assertTrue(factory instanceof AbstractFactory);
		
		factory = Factory.getFactory(Theme.Dark);
		assertTrue(factory instanceof AbstractFactory);
	}

	@Test
	void defaultFactoryTest() {
		AbstractFactory factory = Factory.getFactory(Theme.Default);
		assertTrue(factory instanceof DefaultFactory);
	}

	@Test
	void darkFactoryTest() {
		AbstractFactory factory = Factory.getFactory(Theme.Dark);
		assertTrue(factory instanceof DarkFactory);
	}
	
	@Test
	void darkComponentsTest() {
		AbstractFactory factory = Factory.getFactory(Theme.Dark);
		JButton button = factory.getButton("TestButton");
		assertTrue(button instanceof DarkButton);
		
		JRadioButton radioButton = factory.getRadioButton("TestRadioButton");
		assertTrue(radioButton instanceof DarkRadioButton);
		
		JPanel panel = factory.getPanel();
		assertTrue(panel instanceof DarkPanel);
		
		JLabel label = factory.getLabel("TestLabel");
		assertTrue(label instanceof DarkLabel);
	}
	
	@Test
	void defaultComponentsTest() {
		AbstractFactory factory = Factory.getFactory(Theme.Default);
		JButton button = factory.getButton("TestButton");
		assertTrue(button instanceof DefaultButton);
		
		JRadioButton radioButton = factory.getRadioButton("TestRadioButton");
		assertTrue(radioButton instanceof DefaultRadioButton);
		
		JPanel panel = factory.getPanel();
		assertTrue(panel instanceof DefaultPanel);
		
		JLabel label = factory.getLabel("TestLabel");
		assertTrue(label instanceof DefaultLabel);
	}
	
	@Test
	void nullTheme() {
		AbstractFactory factory = Factory.getFactory(null);
		assertTrue(factory == null);
		
	}
}
