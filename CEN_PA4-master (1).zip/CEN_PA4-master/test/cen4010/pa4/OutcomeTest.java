package cen4010.pa4;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import org.junit.jupiter.api.Test;

import cen4010.pa4.core.Window;
import cen4010.pa4.game.Board;
import cen4010.pa4.game.Outcome;
import cen4010.pa4.game.Player;
import cen4010.pa4.states.Game;

public class OutcomeTest {
	GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
	GraphicsDevice graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();
	GraphicsConfiguration graphicsConfiguration = graphicsDevice.getDefaultConfiguration();
	
	@Test
	void winTest() {
		Window window = new Window(500, 500, graphicsConfiguration);
		Game game = new Game(window);
		Player player1 = new Player("Player1", 1, game);
		
		{
			Board board = new Board(3, 3);
			board.setCell(0, 0, player1.getPlayerId());
			board.setCell(1, 0, player1.getPlayerId());
			board.setCell(2, 0, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(win);
		}
		{
			Board board = new Board(3, 3);
			board.setCell(0, 0, player1.getPlayerId());
			board.setCell(0, 1, player1.getPlayerId());
			board.setCell(0, 2, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(win);
		}
		{
			Board board = new Board(3, 3);
			board.setCell(0, 0, player1.getPlayerId());
			board.setCell(1, 1, player1.getPlayerId());
			board.setCell(2, 2, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(win);
		}
		{
			Board board = new Board(3, 3);
			board.setCell(0, 2, player1.getPlayerId());
			board.setCell(1, 1, player1.getPlayerId());
			board.setCell(2, 0, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(win);
		}
	}
	
	@Test
	void loseTest() {
		Window window = new Window(500, 500, graphicsConfiguration);
		Game game = new Game(window);
		Player player1 = new Player("Player1", 1, game);
		
		{
			Board board = new Board(3, 3);
			board.setCell(0, 0, player1.getPlayerId());
			board.setCell(2, 1, player1.getPlayerId());
			board.setCell(1, 0, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(!win);
		}
		{
			Board board = new Board(3, 3);
			board.setCell(0, 0, player1.getPlayerId());
			board.setCell(1, 2, player1.getPlayerId());
			board.setCell(0, 1, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(!win);
		}
		{
			Board board = new Board(3, 3);
			board.setCell(0, 0, player1.getPlayerId());
			board.setCell(2, 1, player1.getPlayerId());
			board.setCell(1, 2, player1.getPlayerId());
			boolean win = Outcome.isWin(player1, board, Math.max(2, Math.min(3, Math.min(3, 3)))) > -1;
			assertTrue(!win);
		}
	}
}
