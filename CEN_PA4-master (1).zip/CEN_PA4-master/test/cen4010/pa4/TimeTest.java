package cen4010.pa4;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;

import cen4010.pa4.core.Time;

public class TimeTest {
	@Test
	void timeTest() {
		Time.calculateFrameTimeStart();
		Time.calculateFrameTimeEnd();
		Time.calculateTimer();
		assertNotNull(Time.getDelta());
		assertNotNull(Time.getFPS());
		assertNotNull(Time.getTime());
	}
}
