package cen4010.pa4;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import javax.swing.JFrame;
import org.junit.jupiter.api.Test;

import cen4010.pa4.core.State;
import cen4010.pa4.core.Window;
import cen4010.pa4.factory.Theme;

class WindowTest {
	GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
	GraphicsDevice graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();
	GraphicsConfiguration graphicsConfiguration = graphicsDevice.getDefaultConfiguration();

	@Test
	void windowTest() {		
		Window w1 = new Window(500, 500, graphicsConfiguration);

		JFrame f1 = new JFrame();
		f1.setSize(500, 500);
		assertEquals(f1.getWidth(), w1.getWidth());
		assertEquals(f1.getHeight(), w1.getHeight());
	}
	
	@Test
	void stateTest2() {
		Window w1 = new Window(500, 500, graphicsConfiguration);

		State test1 = new State("Test1", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		State test2 = new State("Test2", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		State test3 = new State("Test3", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		
		w1.addState(test1);
		assertNull(w1.peekState());
		w1.addState(test2);
		assertNull(w1.peekState());
		w1.addState(test3);
		assertNull(w1.peekState());
		
		w1.pushState("Test1");
		assertEquals(w1.peekState(), test1);
		w1.pushState("Test2");
		assertEquals(w1.peekState(), test2);
		w1.pushState("Test3");
		assertEquals(w1.peekState(), test3);
		
		w1.popState();
		assertEquals(w1.peekState(), test2);
		w1.popState();
		assertEquals(w1.peekState(), test1);
		
		w1.run();
		
		w1.reload();
		
	}
	
	@Test
	void stateTest() {
		Window w1 = new Window(500, 500, graphicsConfiguration);

		State test1 = new State("Test1", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		State test2 = new State("Test2", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		State test3 = new State("Test3", w1) {
			@Override public void load() {}
			@Override public void enter() {}
			@Override public void update() {}
			@Override public void draw() {}
			@Override public void exit() {}
		};
		w1.pushState(test1);
		assertEquals(w1.peekState(), test1);
		w1.pushState(test2);
		assertEquals(w1.peekState(), test2);
		w1.pushState(test3);
		assertEquals(w1.peekState(), test3);
		
		w1.popState();
		assertEquals(w1.peekState(), test2);
		w1.popState();
		assertEquals(w1.peekState(), test1);
		w1.popState();
	}
	
	@Test
	void themeChangeTest() {
		Window w1 = new Window(500, 500, graphicsConfiguration);
		
		w1.setWindowTheme(Theme.Default);
		w1.setWindowTheme(Theme.Dark);
	}
}
