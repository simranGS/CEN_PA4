1) Our TicTacToe Project does not need any external file dependencies.
2) In eclipse, simply compile and run the game class. Our GUI will pop up and from there,
we have an options menu where you can select the theme, the game mode (player vs player or
vs computer), and the tic-tac-toe grid size. Simply hit the play button and the game begins.
3) The computer advanced AI is a strong point in our project because it can make moves
based on what in needs. (i.e. it will block a player win or try to win on its own). A weak
point in our program is that you have to re-run the program in order to play a new game versus 
the computer. This is because the computer player can only handle one game at a time.
