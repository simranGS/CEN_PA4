package cen4010.pa4.factory.darkTheme;

import java.awt.Color;

import javax.swing.JLabel;

public class DarkLabel extends JLabel {
	private static final long serialVersionUID = 1L;
	
	public DarkLabel(String text) {
		super(text);
		setForeground(Color.lightGray);
	}
	
}
