package cen4010.pa4.factory.darkTheme;

import java.awt.Color;

import javax.swing.JPanel;

public class DarkPanel extends JPanel {
	private static final long serialVersionUID = 501975520144853845L;
	
	public DarkPanel() {
		setBackground(new Color(38, 40, 45));
	}

}
