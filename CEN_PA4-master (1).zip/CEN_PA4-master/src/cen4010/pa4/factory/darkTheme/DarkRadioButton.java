package cen4010.pa4.factory.darkTheme;

import java.awt.Color;

import javax.swing.JRadioButton;

public class DarkRadioButton extends JRadioButton {
	private static final long serialVersionUID = 1866605901004943176L;

	public DarkRadioButton(String text) {
		super(text);
		setBackground(new Color(38, 40, 45));
		setForeground(Color.lightGray);
	}
}
