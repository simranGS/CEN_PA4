package cen4010.pa4.factory.darkTheme;

import java.awt.Color;

import javax.swing.JButton;

public class DarkButton extends JButton {
	private static final long serialVersionUID = -4013806604288251315L;

	public DarkButton(String text) {
		super(text);
		setBackground(new Color(30, 30, 30));
		setForeground(Color.lightGray);
	}
}
