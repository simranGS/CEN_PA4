package cen4010.pa4.factory.darkTheme;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import cen4010.pa4.factory.AbstractFactory;

public class DarkFactory implements AbstractFactory {

	@Override
	public JPanel getPanel() {
		return new DarkPanel();
	}

	@Override
	public JButton getButton(String text) {
		return new DarkButton(text);
	}

	@Override
	public JRadioButton getRadioButton(String text) {
		return new DarkRadioButton(text);
	}

	@Override
	public JLabel getLabel(String text) {
		return new DarkLabel(text);
	}

}
