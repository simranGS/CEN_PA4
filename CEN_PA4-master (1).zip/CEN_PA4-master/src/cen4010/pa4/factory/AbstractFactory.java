package cen4010.pa4.factory;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public interface AbstractFactory
{
    JPanel getPanel();
    JLabel getLabel(String text);
    JButton getButton(String text);
    JRadioButton getRadioButton(String text);
}