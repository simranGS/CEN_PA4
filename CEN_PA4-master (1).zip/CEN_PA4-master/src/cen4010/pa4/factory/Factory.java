package cen4010.pa4.factory;

import cen4010.pa4.factory.darkTheme.DarkFactory;
import cen4010.pa4.factory.defaultTheme.DefaultFactory;

public class Factory {
    public static AbstractFactory getFactory(Theme theme) {
        if (theme == Theme.Default) {
            return new DefaultFactory();
        } else if (theme == Theme.Dark) {
        	return new DarkFactory();
        }
        return null;
    }
}