package cen4010.pa4.factory.defaultTheme;

import java.awt.Color;

import javax.swing.JPanel;

public class DefaultPanel extends JPanel {
	private static final long serialVersionUID = -3224643538314385347L;

	public DefaultPanel() {
		setBackground(Color.LIGHT_GRAY);
	}
}
