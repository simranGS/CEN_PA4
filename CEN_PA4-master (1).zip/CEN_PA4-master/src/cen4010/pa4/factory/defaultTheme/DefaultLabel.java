package cen4010.pa4.factory.defaultTheme;

import java.awt.Color;

import javax.swing.JLabel;

public class DefaultLabel extends JLabel {
	private static final long serialVersionUID = 1L;
	
	public DefaultLabel(String text) {
		super(text);
	}
	
}
