package cen4010.pa4.factory.defaultTheme;

import javax.swing.JButton;

public class DefaultButton extends JButton {
	private static final long serialVersionUID = 4988378595267287067L;

	public DefaultButton(String text) {
		super(text);
		setBackground(getBackground());
	}
}
