package cen4010.pa4.factory.defaultTheme;

import java.awt.Color;

import javax.swing.JRadioButton;

public class DefaultRadioButton extends JRadioButton {
	private static final long serialVersionUID = 1866605901004943176L;

	public DefaultRadioButton(String text) {
		super(text);
		setBackground(Color.LIGHT_GRAY);
	}
}
