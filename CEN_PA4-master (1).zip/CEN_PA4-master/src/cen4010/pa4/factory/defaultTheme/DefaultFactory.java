package cen4010.pa4.factory.defaultTheme;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import cen4010.pa4.factory.AbstractFactory;
import cen4010.pa4.factory.darkTheme.DarkLabel;

public class DefaultFactory implements AbstractFactory {

	@Override
	public JPanel getPanel() {
		return new DefaultPanel();
	}

	@Override
	public JButton getButton(String text) {
		return new DefaultButton(text);
	}

	@Override
	public JRadioButton getRadioButton(String text) {
		return new DefaultRadioButton(text);
	}

	@Override
	public JLabel getLabel(String text) {
		return new DefaultLabel(text);
	}
}