package cen4010.pa4.factory;

public enum Theme {
	Default,
	Dark
}
