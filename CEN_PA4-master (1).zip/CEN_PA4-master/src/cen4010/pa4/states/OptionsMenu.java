package cen4010.pa4.states;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import cen4010.pa4.core.DocumentSizeFilter;
import cen4010.pa4.core.State;
import cen4010.pa4.core.Window;
import cen4010.pa4.factory.Theme;
import cen4010.pa4.tween.Tween;

public class OptionsMenu extends State {
	
	BoxLayout boxLayout;
	
	JTextField WidthField;
	JTextField HeightField;
	JTextField LengthField;

	public OptionsMenu(Window parent) {
		super("Options", parent);
	}
	
	@Override
	public void load() {
		mainPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

		boxLayout = new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS);
		mainPanel.setLayout(boxLayout);
		
		JButton BackButton = factory.getButton("Back");
		BackButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		mainPanel.add(BackButton);

		JRadioButton DefaultButton = factory.getRadioButton("Default");
		DefaultButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		DefaultButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getWindow().setWindowTheme(Theme.Default);
			}
		});
		
		
		JRadioButton DarkButton = factory.getRadioButton("Dark");
		DarkButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		DarkButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getWindow().setWindowTheme(Theme.Dark);
			}
		});
		
		ButtonGroup themeGroup = new ButtonGroup();
		themeGroup.add(DefaultButton);
		themeGroup.add(DarkButton);

		mainPanel.add(DefaultButton);
		mainPanel.add(DarkButton);


		JRadioButton ComputerOn = factory.getRadioButton("ComputerOn");
		ComputerOn.setAlignmentX(Component.CENTER_ALIGNMENT);
		ComputerOn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Game.computer = true;
			}
		});
		
		
		JRadioButton ComputerOff = factory.getRadioButton("ComputerOff");
		ComputerOff.setAlignmentX(Component.CENTER_ALIGNMENT);
		ComputerOff.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Game.computer = false;
			}
		});
		
		ButtonGroup computerGroup = new ButtonGroup();
		computerGroup.add(ComputerOn);
		computerGroup.add(ComputerOff);

		mainPanel.add(ComputerOn);
		mainPanel.add(ComputerOff);
		
		
		
		
		
		
		
		

		int fontSize = BackButton.getFont().getSize();

		JPanel Dimensions = factory.getPanel();
		Dimensions.setLayout(new BoxLayout(Dimensions, BoxLayout.LINE_AXIS));
		Dimensions.setSize(new Dimension(500 + 0 * mainPanel.getSize().width / 4, Dimensions.getSize().height));
		
		WidthField = new JTextField();
		WidthField.setText("3");
		WidthField.setAlignmentX(Component.CENTER_ALIGNMENT);
		WidthField.setColumns(10);
		WidthField.setMaximumSize(new Dimension(40, fontSize + 10));
		((AbstractDocument) WidthField.getDocument()).setDocumentFilter(new DocumentSizeFilter(5));

		HeightField = new JTextField();
		HeightField.setText("3");
		HeightField.setAlignmentX(Component.CENTER_ALIGNMENT);
		HeightField.setColumns(10);
		HeightField.setMaximumSize(new Dimension(40, fontSize + 10));
		((AbstractDocument) HeightField.getDocument()).setDocumentFilter(new DocumentSizeFilter(5));

		LengthField = new JTextField();
		LengthField.setText("3");
		LengthField.setAlignmentX(Component.CENTER_ALIGNMENT);
		LengthField.setColumns(10);
		LengthField.setMaximumSize(new Dimension(40, fontSize + 10));
		((AbstractDocument) LengthField.getDocument()).setDocumentFilter(new DocumentSizeFilter(5));
		
		Dimensions.add(WidthField);
		Dimensions.add(Box.createRigidArea(new Dimension(20, Dimensions.getSize().height)));
		Dimensions.add(HeightField);
		Dimensions.add(Box.createRigidArea(new Dimension(20, Dimensions.getSize().height)));
		Dimensions.add(LengthField);

		mainPanel.add(Dimensions);

		// cool hover animations
		MouseAdapter hoverLogic = new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				super.mouseEntered(e);
				JButton button = (JButton)e.getSource();
				Dimension size = button.getSize();
				Dimension goalSize = new Dimension((int) (size.width * 1.4), (int) (size.height * 1.4));
				Point location = button.getLocation();
				Tween.to(size, goalSize,
				(from, to, equation) -> {
					return new Dimension((int) equation.math(from.width, to.width), (int) equation.math(from.height, to.height));
				}, (delta) -> {
					button.setSize(delta);
					button.setLocation(location.x + (size.width - delta.width) / 2, location.y + (size.height - delta.height) / 2);
				}).duration(0.1).start();
				System.out.println(button.getLocation());
			}
			@Override
			public void mouseExited(MouseEvent e) {
				super.mouseExited(e);
				JButton button = (JButton)e.getSource();
				Dimension size = button.getSize();
				Point location = button.getLocation();
				Dimension goalSize = button.getPreferredSize();
				Tween.to(size, goalSize,
				(from, to, equation) -> {
					return new Dimension((int) equation.math(from.width, to.width), (int) equation.math(from.height, to.height));
				}, (delta) -> {
					button.setSize(delta);
					button.setLocation(location.x + (size.width - delta.width) / 2, location.y + (size.height - delta.height) / 2);
				}).duration(0.1).start();
			}
		};
		BackButton.addMouseListener(hoverLogic);
		
		BackButton.addActionListener((ActionEvent e) -> {
			getWindow().popState();
		});
	}
	@Override
	public void enter() {
	}

	@Override
	public void update() {
	}

	@Override
	public void draw() {
	}

	@Override
	public void exit() {
	}

	@Override
	public void cleanup() {
	}

}
