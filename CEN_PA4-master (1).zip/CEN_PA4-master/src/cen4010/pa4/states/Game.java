package cen4010.pa4.states;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import cen4010.pa4.core.State;
import cen4010.pa4.core.Time;
import cen4010.pa4.core.Window;
import cen4010.pa4.game.Board;
import cen4010.pa4.game.Computer;
import cen4010.pa4.game.Outcome;
import cen4010.pa4.game.Player;

public class Game extends State {
	static boolean playing = false;
	static boolean computer = true;
	Dimension boardDimensions;
	int boardMatchLength;
	
	Board board;
	
	Player[] players;
	int playerTurn;
	int computerMoveCount = 0;
	int totalTurns = 1;
	
	int timeLimit = 10;
	double currentTime = 10;
	double timeOffset = 0;

	public static Game instance;

	JLabel timerText;
	JLabel turnText;
//	JLabel winnerText;
	JPanel gameArea;
	JPanel sideBar;
	
	private ArrayList<JButton> buttons = new ArrayList<>();
	
	public JButton getButton(int index) {
		return buttons.get(index);
	}

	public Game(Window parent) {
		super("Game", parent);
	}
	
	private void resetTimer() {
		timeOffset = Time.getTime();
	}
	
	private void updateTimer() {
		double time = Time.getTime();
		currentTime = timeLimit - time + timeOffset;
	}

	public void gameStart(int boardWidth, int boardHeight, int matchLength) {
		computerMoveCount = 0;
		playerTurn = 0;
		playing = true;
		boardDimensions = new Dimension(boardWidth, boardHeight);
		boardMatchLength = matchLength;
		totalTurns = boardWidth * boardHeight;
		
		board = new Board(boardWidth, boardHeight);

		if (computer) {
			players = new Player[] { new Player("Player1", 1, this), new Computer("Computer", 2, this) };
		} else {
			players = new Player[] { new Player("Player1", 1, this), new Player("Player2", 2, this) };
		}

		gameArea.setLayout(new GridLayout(boardWidth, boardHeight));		

		turnText.setText(String.format("%s's turn", players[playerTurn].getPlayerName()));

		for(int i = 0; i < (boardWidth * boardHeight); i++) {
			int index = i; // the lambda interacted weirdly with the closure to the loop variable
			int x = index % boardWidth;
			int y = (index / boardWidth);
			JButton button = factory.getButton("");
			
			button.setFont(new Font("Arial", Font.PLAIN, 50));
			
			int m = boardWidth;
			int n = boardHeight;
			int k = matchLength;
			
			button.addActionListener((ActionEvent e) -> {
				totalTurns--;
				Player currentPlayer = players[playerTurn];
				turnText.setText(String.format("%s's turn", players[(playerTurn + 1) % players.length].getPlayerName()));
				
				board.setCell(x, y, currentPlayer.getPlayerId());

				button.setEnabled(false);
				
				if (Outcome.isWin(currentPlayer, board, Math.max(2, Math.min(k, Math.min(m, n)))) > -1) {
					gameEnd(currentPlayer);
				}
				
				int playerId = currentPlayer.getPlayerId();
				button.setText(playerId == 1 ? "O" : "X");

				playerTurn = (playerTurn + 1) % players.length;

				resetTimer();
				if (totalTurns <= 0) {
					gameEnd(null);
				}
			});
			buttons.add(button);
			gameArea.add(button);
		}
		
		resetTimer();
	}

	public void gameEnd() {
		playing = false;
		getWindow().popState();
		board = null;
	}
	public void gameEnd(Player winner) {
		if (winner != null) {
			playing = false;
			for (JButton button : buttons) {
				button.setEnabled(false);
			}
	//		winnerText.setText(String.format("%s wins\n", winner.getPlayerName()));
			System.out.printf("%s wins\n", winner.getPlayerName());
		} else {
			System.out.println("Tie");
		}
		board = null;
		getWindow().popState();
		getWindow().popState();
	}

	@Override
	public void load() {
		Dimension screenSize = getWindow().dimensions;
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.LINE_AXIS));

		gameArea = factory.getPanel();
		gameArea.setPreferredSize(new Dimension(screenSize.width - screenSize.width / 6, screenSize.height));
		gameArea.setLayout(new GridLayout(3, 3));
		addComponent(gameArea);

		sideBar = factory.getPanel();
		sideBar.setPreferredSize(new Dimension(screenSize.width / 6, screenSize.height));
		sideBar.setLayout(new BoxLayout(sideBar, BoxLayout.PAGE_AXIS));
		addComponent(sideBar);

		timerText = factory.getLabel("TIMER");
		sideBar.add(timerText);
		
//		winnerText = factory.getLabel("");
//		sideBar.add(winnerText);
		
		turnText = factory.getLabel("TURN");
		sideBar.add(turnText);
		
		
//		JButton exitButton = factory.getButton("Exit");
//		exitButton.addActionListener((ActionEvent e) -> {
//			gameEnd();
//		});
//		sideBar.add(exitButton);
	}

	@Override
	public void enter() {
		OptionsMenu options = ((OptionsMenu)getWindow().allStates.get("Options"));
		int width = Integer.parseInt(options.WidthField.getText());
		int height = Integer.parseInt(options.HeightField.getText());
		int length = Integer.parseInt(options.LengthField.getText());
		
		gameStart(height, width, length);
	}

	@Override
	public void update() {
		if (playing) {
			if (currentTime <= 0) {
				gameEnd(players[(playerTurn + 1) % players.length]);
			}
			
			updateTimer();
			timerText.setText(String.format("Time Left: %f", currentTime));
	
			Player currentPlayer = players[playerTurn];
			
			if (currentPlayer instanceof Computer) {
				System.out.println(computerMoveCount);
				if (computerMoveCount <= 0) {
					System.out.println("BOT RANDOM MOVE");
					((Computer)currentPlayer).move(board);
				} else {
					((Computer)currentPlayer).advancedMove(board, boardMatchLength, players[(playerTurn - 1) % players.length]);
				}
				computerMoveCount++;
			}
		}
	}

	@Override
	public void draw() {
	}

	@Override
	public void exit() {
		for (JButton button : buttons) {
			gameArea.remove(button);
		}
	}

	@Override
	public void cleanup() {
		for (Component component : mainPanel.getComponents()) {
			mainPanel.remove(component);
		}
	}
}
