package cen4010.pa4.states;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.JButton;
import cen4010.pa4.core.State;
import cen4010.pa4.core.Window;
import cen4010.pa4.tween.Tween;

public class StartMenu extends State {
	public StartMenu(Window parent) {
		super("Start", parent);
	}
//	JButton playButton;
	Point startPos;
	Point goalPos;
	
	@Override
	public void load() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		mainPanel.setLayout(gridBagLayout);

		JButton playButton = factory.getButton("Play");
		{
			playButton.setAlignmentX(Component.CENTER_ALIGNMENT);
			GridBagConstraints constraints = new GridBagConstraints();
			constraints.gridx = 1;
			constraints.gridy = 0;
			constraints.weighty = 1;
			addComponent(playButton, constraints);
		}
		JButton optionsButton = factory.getButton("Options");
		{
			optionsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
			GridBagConstraints constraints = new GridBagConstraints();
			constraints.gridx = 1;
			constraints.gridy = 1;
			constraints.weighty = 1;
			addComponent(optionsButton, constraints);
		}
		JButton exitButton = factory.getButton("Exit");
		{
			exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
			GridBagConstraints constraints = new GridBagConstraints();
			constraints.gridx = 1;
			constraints.gridy = 2;
			constraints.weighty = 1;
			addComponent(exitButton, constraints);
		}
		
		{
			GridBagConstraints constraints = new GridBagConstraints();
			constraints.gridx = 1;
			constraints.gridy = 3;
			constraints.gridheight = 1;
			constraints.weighty = 1;
			addComponent(new Box.Filler(null, new Dimension(0, 0), null), constraints);
			constraints.gridy = 4;
			addComponent(new Box.Filler(null, new Dimension(0, 0), null), constraints);

			addComponent(new Box.Filler(null, new Dimension(0, 0), null), constraints);
		}
	
		// cool hover animations
		MouseAdapter hoverLogic = new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				super.mouseEntered(e);
				JButton button = (JButton)e.getSource();
				Dimension size = button.getSize();
				Dimension goalSize = new Dimension((int) (size.width * 1.4), (int) (size.height * 1.4));
				Point location = button.getLocation();
				Tween.to(size, goalSize,
				(from, to, equation) -> {
					return new Dimension((int) equation.math(from.width, to.width), (int) equation.math(from.height, to.height));
				}, (delta) -> {
					button.setSize(delta);
					button.setLocation(location.x + (size.width - delta.width) / 2, location.y + (size.height - delta.height) / 2);
				}).duration(0.1).start();
				System.out.println(button.getLocation());
			}
			@Override
			public void mouseExited(MouseEvent e) {
				super.mouseExited(e);
				JButton button = (JButton)e.getSource();
				Dimension size = button.getSize();
				Point location = button.getLocation();
				Dimension goalSize = button.getPreferredSize();
				Tween.to(size, goalSize,
				(from, to, equation) -> {
					return new Dimension((int) equation.math(from.width, to.width), (int) equation.math(from.height, to.height));
				}, (delta) -> {
					button.setSize(delta);
					button.setLocation(location.x + (size.width - delta.width) / 2, location.y + (size.height - delta.height) / 2);
				}).duration(0.1).start();
			}
		};
		playButton.addMouseListener(hoverLogic);
		optionsButton.addMouseListener(hoverLogic);
		exitButton.addMouseListener(hoverLogic);

		// what the buttons do
		playButton.addActionListener((ActionEvent e) -> {
			getWindow().pushState("Game");
		});
		optionsButton.addActionListener((ActionEvent e) -> {
			getWindow().pushState("Options");
		});
		exitButton.addActionListener((ActionEvent e) -> {
			getWindow().listener.windowClosing(new WindowEvent(getWindow(), WindowEvent.WINDOW_CLOSING));
		});		
	}

	@Override
	public void enter() {
	}

	@Override
	public void exit() {
	}
	
	@Override
	public void update() {
	}

	@Override
	public void draw() {
	}

	@Override
	public void cleanup() {
	}
}
