package cen4010.pa4.core;

// all of a state's methods
public interface StateMethods {
	public void load();
	
	public void cleanup();
	
	public void enter();
	
	public void update();
	
	public void draw();

	public void exit();
}
