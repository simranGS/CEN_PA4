package cen4010.pa4.core;

import java.awt.Component;

import javax.swing.JPanel;

import cen4010.pa4.factory.AbstractFactory;
import cen4010.pa4.factory.Factory;
import cen4010.pa4.factory.Theme;

// a window's current state
public abstract class State implements StateMethods {
	protected boolean loaded = false;

	private Window parentWindow;
	protected JPanel mainPanel;	// each state has a JPanel for its components
	
	protected String name;
	
	protected AbstractFactory factory;
	
	public State(String name, Window parent) {
		super();
		this.parentWindow = parent;
		this.name = name;
		setTheme(Theme.Dark);
		mainPanel = factory.getPanel();
	}
	
	public final void reload() {
		cleanup();
		mainPanel.removeAll();
		mainPanel = factory.getPanel();
		load();
	}
	
	public final void addComponent(Component component) {
		mainPanel.add(component);
	}
	public final void addComponent(Component component, Object constraints) {
		mainPanel.add(component, constraints);
	}
	
	public void cleanup() {
	}
	
	public void setTheme(Theme theme) {
		factory = Factory.getFactory(theme);	
	}

	public Window getWindow() {
		return parentWindow;
	}

	public void setWindow(Window parent) {
		this.parentWindow = parent;
	}
}
