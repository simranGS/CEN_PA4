package cen4010.pa4.tween;

// a fnctional interface that represents an equation for use with tweening
@FunctionalInterface
public interface TweenEquation {
	public double math(double a, double b);
}
