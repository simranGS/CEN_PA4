package cen4010.pa4.tween;

// an enum of all available tweening types
public enum TweenType {
	QuadIn;
}
