package cen4010.pa4.game;

public class Outcome {	
	public static int isWin(Player player, Board board, int k) {
        int sizeX = board.getSizeX();
        int sizeY = board.getSizeY() - 1;
        
        int currentPlayerChecking = board.getCell(0);
        int checkAccumulator = 1;
        
        // horizontal
        for (int y = 0; y < sizeY; y++) {
        	currentPlayerChecking = board.getCell(0, y);
        	checkAccumulator = 1;
	        for (int x = 1; x < sizeX; x++) {
	        	int value = board.getCell(x, y);
	        	if (value == currentPlayerChecking && value != -1) {
	        		checkAccumulator++;
	        	} else {
	                currentPlayerChecking = board.getCell(x, y);
	                checkAccumulator = 1;
	        	}

//                System.out.printf("(%d, %d); accum: %d, player: %d\n", x, y, checkAccumulator, currentPlayerChecking);
	        	if (checkAccumulator >= k) {
//                    System.out.println("Won on horizontal");
	        		return currentPlayerChecking;
	        	}
	        }
        }

        for (int x = 0; x < sizeX; x++) {
        	currentPlayerChecking = board.getCell(x, 0);
        	checkAccumulator = 1;
        	for (int y = 1; y < (sizeY + 1); y++) {
	        
	        	int value = board.getCell(x, y);
	        	if (value == currentPlayerChecking && value != -1) {
	        		checkAccumulator++;
	        	} else {
	                currentPlayerChecking = board.getCell(x, y);
	                checkAccumulator = 1;
	        	}

//                System.out.printf("(%d, %d); accum: %d, player: %d\n", x, y, checkAccumulator, currentPlayerChecking);
	        	if (checkAccumulator >= k) {
//                    System.out.println("Won on vertical");
	        		return currentPlayerChecking;
	        	}
	        }
        }
        
        for (int x = 0; x < (sizeX - k + 1); x++) {
            for (int y = 0; y < (sizeY - (k - 1) + 1); y++) {
            	currentPlayerChecking = board.getCell(x, y);
            	checkAccumulator = 0;
            	// diagonal down
            	for (int x2 = x, y2 = y; x2 < k + x; x2++, y2++) {
    	        	int value = board.getCell(x2, y2);
    	        	if (value == currentPlayerChecking && value != -1) {
    	        		checkAccumulator++;
    	        	} else {
    	                currentPlayerChecking = board.getCell(x, y);
    	                checkAccumulator = 1;
    	        		break;
    	        	}
    
//                    System.out.printf("(%d, %d); accum: %d, value: %d, player: %d\n", x2, y2, checkAccumulator, value, currentPlayerChecking);
    	        	if (checkAccumulator >= k) {
//                        System.out.println("Won on diagonal down");
    	        		return currentPlayerChecking;
    	        	}
            		
            	}
            }

            for (int y = sizeY; y >= k - 1; y--) {
            	currentPlayerChecking = board.getCell(x, y);
            	checkAccumulator = 0;
	        	for (int x2 = x, y2 = y; x2 < k + x; x2++, y2--) {
    	        	int value = board.getCell(x2, y2);
    	        	if (value == currentPlayerChecking && value != -1) {
    	        		checkAccumulator++;
    	        	} else {
    	                currentPlayerChecking = board.getCell(x, y);
    	                checkAccumulator = 1;
    	        		break;
    	        	}
//                    System.out.printf("(%d, %d); accum: %d, value: %d, player: %d\n", x2, y2, checkAccumulator, value, currentPlayerChecking);
    	        	if (checkAccumulator >= k) {
//                        System.out.println("Won on diagonal up");
    	        		return currentPlayerChecking;
    	        	}
	        	}
            }
        }
		
        return -1;
	}
}
