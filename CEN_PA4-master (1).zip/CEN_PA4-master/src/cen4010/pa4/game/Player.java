package cen4010.pa4.game;

import cen4010.pa4.states.Game;

/* 
 * Player class creates player objects that can make moves
 * 
 * @param playerName 
 */

public class Player {
	private int playerId = -1;
    private String playerName;
	
	protected Game game;
	
	public Player (String playerName, int id, Game game) {// constructor for player object
		this.playerName = playerName;
		playerId = id;
		this.game = game;
	}
	
	public String getPlayerName () {//getter for player name
	    return playerName;
	}

	//added String move to method for adding board input to a player
//	public boolean move(Board board, int row, int column) {
//		if (board.getCell(column, row) == -1) {
//			board.setCell(column, row, playerId);
//			return true;
//		}
//		return false;
//	}
//	
	public int getPlayerId() {
		return playerId;
	}
}
