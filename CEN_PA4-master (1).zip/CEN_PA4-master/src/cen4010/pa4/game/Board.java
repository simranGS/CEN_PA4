package cen4010.pa4.game;

public class Board {
	private int[][] layout;
	private int sizeX;
	private int sizeY;
	
	public Board(int sizeX, int sizeY) {
		this.sizeX = sizeX;
		this.sizeY = sizeY;
		layout = new int[sizeX][sizeY];

		for (int y = 0; y < sizeY; y++) {
			for (int x = 0; x < sizeX; x++) {
				layout[x][y] = -1;
			}
		}
	}
	
	int[][] getCells() {
		return layout;
	}
	int getCell(int x, int y) {
		return layout[x][y];
	}
	int getCell(int index) {
//		System.out.printf("(%d, %d)\n", index % sizeX, index / sizeY);
//		System.out.printf("(%d, %d)\n", sizeX, sizeY);
		return layout[index % sizeX][index / sizeX];
	}
	public void setCell(int x, int y, int value) {
		layout[x][y] = value;
	}
	public int getSizeX() {
		return sizeX;
	}
	public int getSizeY() {
		return sizeY;
	}
}
