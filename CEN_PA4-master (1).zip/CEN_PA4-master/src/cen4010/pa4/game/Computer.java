package cen4010.pa4.game;
import java.util.Random;

import cen4010.pa4.states.Game;

public class Computer extends Player {
	
	Outcome o = new Outcome();
	private int indexS = 0;
	Random rand = new Random();
	
	public Computer(String playerName, int id, Game game) {
		super(playerName, id, game);
	}

	public boolean move(Board board) {
		int index = 0;
		index = rand.nextInt(board.getSizeX() * board.getSizeY());
		
		while (board.getCell(index) != -1) {
			index = (++index) % (board.getSizeX() * board.getSizeY());
		}
		
		indexS = index;

		game.getButton(index).doClick();
		return true;
	}
	
	public boolean advancedMove(Board board, int k, Player player) {		
//		System.out.println("Index: " + indexS);
//		System.out.println("Board Size: " + ((board.getSizeX() * board.getSizeY()) - 1));
		
//		if(canWin(board, k)) {
//			return true;
//		}
		
		if(blockWin(board, player, k)) {
			return true;
		}
		
		//Top Left Corner of Grid
		if(indexS == 0) {
//			System.out.println("Top Left Corner");
			if(board.getCell(indexS + 1) == -1) {
				moveRight(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY() + 1) == -1) {
				moveBottomRight(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY()) == -1) {
				moveBottom(board);
				return true;
			}
			move(board);
		}
		//Top Right Corner of Grid
		else if(indexS == board.getSizeY() - 1) {
//			System.out.println("Top Right Corner");
			if(board.getCell(indexS - 1) == -1) {
				moveLeft(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY() - 1) == -1) {
				moveBottomLeft(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY()) == -1) {
				moveBottom(board);
				return true;
			}
			move(board);
		}
		//Bottom Right Corner of Grid
		else if(indexS == (board.getSizeX() * board.getSizeY())) {
//			System.out.println("Bottom Right Corner");
			if(board.getCell(indexS - board.getSizeY()) == -1) {
				moveTop(board);
				return true;
			}
			else if(board.getCell(indexS - board.getSizeY() + 1) == -1) {
				moveTopLeft(board);
				return true;
			}
			else if(board.getCell(indexS - 1) == -1) {
				moveLeft(board);
				return true;
			}
			move(board);
		}
		//Bottom Left Corner of Grid
		else if(indexS == ((board.getSizeX() * board.getSizeY()) - 1) - (board.getSizeY() - 1)) {
//			System.out.println("Bottom Left Corner");
			if(board.getCell(indexS - board.getSizeY()) == -1) {
				moveTop(board);
				return true;
			}
			else if(board.getCell(indexS - board.getSizeY() - 1) == -1) {
				moveTopRight(board);
				return true;
			}
			else if(board.getCell(indexS + 1) == -1) {
				moveRight(board);
				return true;
			}
			move(board);
		}
		//Check Top Row
		else if(indexS % getIndexSize(board) < board.getSizeY()) {
//			System.out.println("Top Row");
			if(board.getCell(indexS + 1) == -1) {
				moveRight(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY() + 1) == -1) {
				moveBottomRight(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY()) == -1) {
				moveBottom(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY() - 1) == -1) {
				moveBottomLeft(board);
				return true;
			}
			else if(board.getCell(indexS - 1) == -1) {
				moveLeft(board);
				return true;
			}
			move(board);
		}
		//Check Bottom Row
		else if(indexS % getIndexSize(board) > getIndexSize(board) - board.getSizeY() - 1) {
//			System.out.println("Bottom Row");
			if(board.getCell(indexS - 1) == -1) {
				moveLeft(board);
				return true;
			}
			else if(board.getCell(indexS - board.getSizeY() + 1) == -1) {
				moveTopLeft(board);
				return true;
			}
			else if(board.getCell(indexS - board.getSizeY()) == -1) {
				moveTop(board);
				return true;
			}
			else if(board.getCell(indexS - board.getSizeY() - 1) == -1) {
				moveTopRight(board);
				return true;
			}
			else if(board.getCell(indexS + 1) == -1) {
				moveRight(board);
				return true;
			}
			move(board);
		}
		//Check Right Column
		else if(indexS % board.getSizeY() == board.getSizeY() - 1) {
//			System.out.println("Right Column");
			if(board.getCell(indexS - board.getSizeY()) == -1) {
//				System.out.println("1");
				moveTop(board);
				return true;
			}
			else if(board.getCell(indexS - (board.getSizeY() + 1)) == -1) {
//				System.out.println("2");
				moveTopLeft(board);
				return true;
			}
			else if(board.getCell(indexS - 1) == -1) {
//				System.out.println("3");
				moveLeft(board);
				return true;
			}
			else if(board.getCell(indexS + (board.getSizeY() - 1)) == -1) {
//				System.out.println("4");
				moveBottomLeft(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY()) == -1) {
//				System.out.println("5");
				moveBottom(board);
				return true;
			}
			move(board);
		}
		//check Left Column
		else if(indexS % board.getSizeY() == 0) {
//			System.out.println("Left Column");
			if(board.getCell(indexS - board.getSizeY()) == -1) {
//				System.out.println("1");
				moveTop(board);
				return true;
			}
			else if(board.getCell(indexS - (board.getSizeY() - 1)) == -1) {
//				System.out.println("2");
				moveTopRight(board);
				return true;
			}
			else if(board.getCell(indexS + 1) == -1) {
//				System.out.println("3");
				moveRight(board);
				return true;
			}
			else if(board.getCell(indexS + (board.getSizeY() + 1)) == -1) {
//				System.out.println("4");
				moveBottomRight(board);
				return true;
			}
			else if(board.getCell(indexS + board.getSizeY()) == -1) {
//				System.out.println("5");
				moveBottom(board);
				return true;
			}
			move(board);
		}
		else {
			int num = 0;
			int count = 0;
			while(count < 10000) {
				num = rand.nextInt(9);
//				System.out.println("Random Number: " + num);
//				System.out.println("Played Center");
				if(board.getCell(indexS - (board.getSizeY() + 1)) == -1 && num == 1) {
//					System.out.println("1");
					moveTopLeft(board);
					return true;
				}
				else if(board.getCell(indexS - board.getSizeY()) == -1 && num == 2) {
//					System.out.println("2");
					moveTop(board);
					return true;
				}
				else if(board.getCell(indexS - (board.getSizeY() - 1)) == -1 && num == 3) {
//					System.out.println("3");
					moveTopRight(board);
					return true;
				}
				else if(board.getCell(indexS + 1) == -1 && num == 4) {
//					System.out.println("4");
					moveRight(board);
					return true;
				}
				else if(board.getCell(indexS + (board.getSizeY() + 1)) == -1 && num == 5) {
//					System.out.println("5");
					moveBottomRight(board);
					return true;
				}
				else if(board.getCell(indexS + board.getSizeY()) == -1 && num == 6) {
//					System.out.println("6");
					moveBottom(board);
					return true;
				}
				else if(board.getCell(indexS + (board.getSizeY() - 1)) == -1 && num == 7) {
//					System.out.println("7");
					moveBottomLeft(board);
					return true;
				}
				else if(board.getCell(indexS - 1) == -1 && num == 8) {
//					System.out.println("8");
					moveLeft(board);
					return true;
				}
				count++;
			}
//			System.out.println("Random Move");
			move(board);
			return true;
		}
		return false;
	}
	
	private int getIndexSize(Board board) {
		return board.getSizeX() * board.getSizeY();
	}
	
	//move at top left of previous move
	private void moveTopLeft(Board board) {
		indexS = indexS - (board.getSizeY() + 1);
		game.getButton(indexS).doClick();
	}
	
	//move at top of previous move
	private void moveTop(Board board) {
		indexS = indexS - board.getSizeY();
		game.getButton(indexS).doClick();
	}
	
	//move at top right of previous move
	private void moveTopRight(Board board) {
		indexS = indexS - (board.getSizeY() - 1);
		game.getButton(indexS).doClick();
	}
	
	//move at right of previous move
	private void moveRight(Board board) {
		indexS = indexS + 1;
		game.getButton(indexS).doClick();
	}
	
	//move at bottom right of previous move
	private void moveBottomRight(Board board) {
		indexS = indexS + (board.getSizeY() + 1);
		game.getButton(indexS).doClick();
	}
	
	//move at bottom of previous move
	private void moveBottom(Board board) {
		indexS = indexS + board.getSizeY();
		game.getButton(indexS).doClick();
	}
	
	//move at bottom left of previous move
	private void moveBottomLeft(Board board) {
		indexS = indexS + (board.getSizeY() - 1);
		game.getButton(indexS).doClick();
	}
	
	private void moveLeft(Board board) {
		indexS = indexS - 1;
		game.getButton(indexS).doClick();
	}
	
	private boolean blockWin(Board board, Player player, int k) {
//		System.out.println("Checking to Blocking Win " + player.getPlayerId() + "  " + board.getCell(3));
		if(Outcome.isWin(player, board, k - 1) == 1) {
//			System.out.println("Blocking Win");
			int track = 0;
			int index = 0;
			int fill = 0;
			if(board.getSizeX() > board.getSizeY()) {
				board.getSizeY();
			}
			else {
				board.getSizeX();
			}
			
			//horizontal
			for(int j, i = 0; i < board.getSizeX(); i++) {
				for(j = 0; j < board.getSizeY(); j++) {
					if(board.getCell(index) == 1) {
						track++;
					}
					if(board.getCell(index) != -1) {
						fill++;
					}
					index++;
				}
//				System.out.println(track + " " + index + " " + fill);
				if(track == k - 1 && fill != board.getSizeY()) {
					game.getButton(index - 1).doClick();
					indexS = index - 1;
					return true;
				}
				track = 0;
				fill = 0;
			}
			
			//vertical
			track = 0;
			index = 0;
			fill = 0;
			for(int j, i = 0; i < board.getSizeY(); i++) {
				for(j = 0; j < board.getSizeX(); j++) {
					if(board.getCell(index) == 1) {
						track++;
					}
					if(board.getCell(index) != -1) {
						fill++;
					}
					index += board.getSizeX();
				}
//				System.out.println(track + " " + index + " " + fill);
				if(track == k - 1 && fill != board.getSizeY()) {
					game.getButton(index - board.getSizeY()).doClick();
					indexS = index - board.getSizeY();
					return true;
				}
				track = 0;
				fill = 0;
				index = i;
			}
		}
		return false;
	}
	
//	private boolean canWin(Board board, int k) {
//		int numberFilled = 0;
//		int numberPlayedByComp = 0;
//		int index = 0;
//		
//		System.out.println("Trying to Win");
//		
//		//search horizontal
//		for(int j, i = 0; i < board.getSizeX(); i++) {
//			for(j = 0; j < board.getSizeY(); j++) {
//				if(board.getCell(index) == 2) {
//					numberPlayedByComp = 0;
//				}
//				if(board.getCell(index) != -1) {
//					numberFilled++;
//				}
//				index++;
//			}
//			System.out.println(numberPlayedByComp + " " + index + " " + numberFilled);
//			if(numberPlayedByComp == k - 1 && numberFilled != board.getSizeY()) {
//				for(int m = index - 1; m < index + board.getSizeY(); m++) {
//					if(board.getCell(m) == -1) {
//						Game.instance.gameWindow.getButton(m).doClick();
//						return true;
//					}
//				}
//			}
//			numberPlayedByComp = 0;
//			numberFilled = 0;
//		}
//		
//		search horizontal
//		for(int j, i = 0; i < k; i++) {
//			for(j = 0; j < k; j++) {
//				if(board.getCell(index) == 2) {
//					numberPlayedByComp = 0;
//				}
//				if(board.getCell(index) != -1) {
//					numberFilled++;
//				}
//				index++;
//			}
//			if(numberPlayedByComp == k - 1 && numberFilled != k) {
//				for(int m = index - 1; m < index + k; m++) {
//					if(board.getCell(m) == -1) {
//						Game.instance.gameWindow.getButton(m).doClick();
//						return true;
//					}
//				}
//			}
//		}
//		return false;
//	}
}